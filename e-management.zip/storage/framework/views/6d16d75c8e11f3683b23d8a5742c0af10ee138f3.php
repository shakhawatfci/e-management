
<?php $__env->startPush('style'); ?>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link href="<?php echo e(asset('admin-assets/plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('admin-assets/assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page_header'); ?>
<li class="breadcrumb-item"><a href="javascript:void(0);">Dashboard</a></li>
<!-- <li class="breadcrumb-item active" aria-current="page"><span>Sales</span></li> -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row layout-top-spacing">

<div class="col-md-8 mx-auto layout-spacing">
    <div class="widget widget-table-two">

        <div class="widget-heading">
            <h5 class="">Last Month Bill Yet Not Done</h5>
        </div>

        <div class="widget-content">
            <div class="table-responsive">
                <table class="table">
                    <thead style="display:table;width:100%;table-layout:fixed;width: calc( 100% - 1em );">
                        <tr>
                            <th><div class="th-content">Project</div></th>
                            <th><div class="th-content">Equipment</div></th>
                            <th><div class="th-content">Type</div></th>
                            <!-- <th><div class="th-content th-heading">Amount</div></th> -->
                        </tr>
                    </thead>
                    <tbody style="display:block;height:400px;overflow-y:auto;width:100%;">
                    <?php if($last_month_due_bill->count() > 0): ?>
                        <?php $__currentLoopData = $last_month_due_bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="display:table;width:100%;table-layout:fixed;">
                                <td><div class="td-content customer-name"><?php echo e($due_bill->project->project_name); ?></div></td>
                                <td><div class="td-content product-brand"><?php echo e($due_bill->equipement->eq_name); ?></div></td>
                                <td><div class="td-content"><?php echo e($due_bill->equipment_type->name); ?></div></td>
                                <!-- <td><div class="td-content pricing"><?php echo e($due_bill->total_project_amount); ?></div></td> -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\e-management\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>