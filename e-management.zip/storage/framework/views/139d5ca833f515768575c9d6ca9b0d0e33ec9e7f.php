
<?php $__env->startSection('title','EMS | Employee Salary'); ?>

<?php $__env->startSection('page_header'); ?>
<li class="breadcrumb-item"><a href="javascript:void(0);">Expense</a></li>
<li class="breadcrumb-item active" aria-current="page"><span>Employee Salary</span></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('create-button'); ?>
<button  data-toggle="modal"  data-target="#CreateEmployeeSalary"
                                         class="btn btn-primary"  data-placement="top" title="Create New employee">
                                        <i class="far fa-plus-square"></i> Create New
                                        </button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">                
                <div class="row layout-spacing layout-top-spacing" id="cancel-row">
                    <div class="col-lg-12">
                        <div class="widget-content searchable-container list">

                            <div class="row">
                        <create-employee-salary></create-employee-salary>                           
                            </div>
                         <view-employee-salary></view-employee-salary>
                        </div>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>

<!-- push the script which you need only this page  -->
<?php $__env->startPush('script'); ?>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<script src="<?php echo e(asset('public/js/employee.js')); ?>"></script>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\e-management\resources\views/employee/salary.blade.php ENDPATH**/ ?>