
<?php $__env->startSection('title','EMS | Project'); ?>

<?php $__env->startSection('page_header'); ?>
<li class="breadcrumb-item"><a href="javascript:void(0);">Project</a></li>
<li class="breadcrumb-item active" aria-current="page"><span>Manage</span></li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">                
    <div class="row layout-spacing layout-top-spacing" id="cancel-row">
        <div class="col-lg-12">
            <div class="widget-content searchable-container list">

                <div class="row">
                    <div class="col-xl-4 col-lg-5 col-md-5 col-sm-7 filtered-list-search layout-spacing align-self-center">
                      <h6 style="margin-top : 20px">Manage Project</h6>
                    </div>

                    <div class="col-xl-8 col-lg-7 col-md-7 col-sm-5 text-sm-right text-center layout-spacing align-self-center">
                        <div class="d-flex justify-content-sm-end justify-content-center">
                            <button  data-toggle="modal"  data-target="#createProject"
                             class="btn btn-primary"  data-placement="top" title="Create New Project">
                            <i class="far fa-plus-square"></i> Create New
                            </button>
                        </div>
                        <create-project></create-project>
                    </div>
                </div>

             <view-project></view-project>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<!-- push the script which you need only this page  -->
<?php $__env->startPush('script'); ?>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<script src="<?php echo e(asset('public/js/project.js')); ?>"></script>
    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<?php $__env->stopPush(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\e-management\resources\views/project/project.blade.php ENDPATH**/ ?>