
## About EMS

EMS or equipment Management system is an open source software by Limmex Automation  which can be used for manage equipment business and partership and vendor .  it's based on Laravel and vue js 


## Contributing

<a href="https://github.com/shakhawatfci/" target="_blank" title="Shakhawat Hossain Sabbir">Shakhawat</a>
<a href="https://github.com/arifuzzaman31/"  target="_blank">Arifuzzaman</a>

and supported by 
<a href="http://automation.limmexbd.com/"  target="_blank">Limmex Automation</a>


